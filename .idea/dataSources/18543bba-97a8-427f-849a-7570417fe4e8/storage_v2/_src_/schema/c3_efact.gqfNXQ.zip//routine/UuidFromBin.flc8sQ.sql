create
    definer = c3_admin@`%` function UuidFromBin(_bin binary(16)) returns binary(36) deterministic security invoker
RETURN LCASE(
	CONCAT_WS(
		'-',
		HEX(SUBSTR( _bin, 5, 4 )),
		HEX(SUBSTR( _bin, 3, 2 )),
		HEX(SUBSTR( _bin, 1, 2 )),
		HEX(SUBSTR( _bin, 9, 2 )),
		HEX(SUBSTR( _bin, 11 )) 
));

