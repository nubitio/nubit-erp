create view vw_impresora as
select `i`.`impresora_id` AS `impresora_id`,
       `i`.`local_id`     AS `local_id`,
       `i`.`marca`        AS `marca`,
       `i`.`modelo`       AS `modelo`,
       `i`.`serie`        AS `serie`,
       `i`.`estado`       AS `estado`,
       `e`.`empresa_id`   AS `empresa_id`,
       `e`.`razon_social` AS `empresa`,
       `l`.`descripcion`  AS `local`
from ((`c3_efact`.`impresora` `i` join `c3_efact`.`local` `l` on (`l`.`local_id` = `i`.`local_id`))
         join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`));

