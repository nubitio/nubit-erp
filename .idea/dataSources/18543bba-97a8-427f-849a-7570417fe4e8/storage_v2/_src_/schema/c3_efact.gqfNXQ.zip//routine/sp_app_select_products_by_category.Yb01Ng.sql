create
    definer = c3_admin@`%` procedure sp_app_select_products_by_category(IN p_category char(36))
BEGIN
  SELECT
		p.producto_id,
		p.descripcion 
	FROM
		producto p 
	WHERE
		p.estado = 1 
		AND p.categoria_id = p_category 
	ORDER BY
		p.descripcion;
END;

