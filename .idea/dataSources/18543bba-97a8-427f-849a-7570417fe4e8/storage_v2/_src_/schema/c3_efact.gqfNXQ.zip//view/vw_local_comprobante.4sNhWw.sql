create definer = c3_admin@`%` view vw_local_comprobante as
select `lc`.`local_id`            AS `local_id`,
       `lc`.`tipo_comprobante_id` AS `tipo_comprobante_id`,
       `lc`.`serie`               AS `serie`,
       `lc`.`serie_asociada`      AS `serie_asociada`,
       `l`.`descripcion`          AS `local`,
       `e`.`empresa_id`           AS `empresa_id`,
       `e`.`razon_social`         AS `empresa`,
       `tc`.`descripcion`         AS `tipo_comprobante`
from (((`c3_efact`.`local_comprobante` `lc` join `c3_efact`.`local` `l` on (`l`.`local_id` = `lc`.`local_id`)) join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`))
         join `c3_efact`.`tipo_comprobante` `tc` on (`tc`.`codigo` = `lc`.`tipo_comprobante_id`));

