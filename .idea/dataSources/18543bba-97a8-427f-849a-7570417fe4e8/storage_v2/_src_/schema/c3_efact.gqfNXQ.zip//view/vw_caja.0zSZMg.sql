create definer = c3_admin@`%` view vw_caja as
select `c`.`caja_id`                                                                    AS `caja_id`,
       `c`.`local_id`                                                                   AS `local_id`,
       `c`.`apertura`                                                                   AS `apertura`,
       `c`.`cierre`                                                                     AS `cierre`,
       `c`.`usuario_id`                                                                 AS `usuario_id`,
       `c`.`estado`                                                                     AS `estado`,
       sum(case when `cd`.`tipo_id` = 1 then `cd`.`monto` else 0 end)                   AS `ingresos`,
       sum(case when `cd`.`tipo_id` = 2 then `cd`.`monto` else 0 end)                   AS `egresos`,
       sum(case when `cd`.`descripcion` = 'FONDO DE CAJA' then `cd`.`monto` else 0 end) AS `saldo_inicial`,
       sum(case when `cd`.`tipo_id` = 1 then `cd`.`monto` else `cd`.`monto` * -1 end)   AS `saldo_final`,
       `u`.`username`                                                                   AS `usuario`,
       `l`.`descripcion`                                                                AS `local`
from (((`c3_efact`.`caja` `c` join `c3_efact`.`caja_detalle` `cd` on (`cd`.`caja_id` = `c`.`caja_id`)) join `c3_efact`.`usuario` `u` on (`u`.`usuario_id` = `c`.`usuario_id`))
         left join `c3_efact`.`local` `l` on (`l`.`local_id` = `c`.`local_id`))
group by `c`.`caja_id`;

