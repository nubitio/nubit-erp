create definer = c3_admin@`%` view vw_asistencia as
select `a`.`id`                                                                     AS `id`,
       `a`.`dni`                                                                    AS `dni`,
       `a`.`fecha`                                                                  AS `fecha`,
       `a`.`hora`                                                                   AS `hora`,
       `a`.`created_by`                                                             AS `created_by`,
       `a`.`updated_by`                                                             AS `updated_by`,
       `a`.`created_at`                                                             AS `created_at`,
       `a`.`updated_at`                                                             AS `updated_at`,
       concat(`e`.`nombres`, ' ', `e`.`apellidos`)                                  AS `empleado`,
       `e`.`tipo_contrato`                                                          AS `tipo_contrato`,
       case `e`.`tipo_contrato` when 1 then 'Planilla' when 2 then 'RH' else '' end AS `contrato`
from (`c3_efact`.`asistencia` `a`
         join `c3_efact`.`empleado` `e` on (`a`.`dni` = `e`.`dni`));

