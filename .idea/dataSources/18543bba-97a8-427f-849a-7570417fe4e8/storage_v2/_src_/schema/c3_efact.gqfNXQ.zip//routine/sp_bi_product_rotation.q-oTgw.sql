create
    definer = c3_admin@`%` procedure sp_bi_product_rotation(IN p_local char(36), IN p_lapse varchar(20))
BEGIN
	SELECT
		p.producto_id,
		p.descripcion as producto,
		IFNULL( m.cantidad, 0 ) AS cantidad 
	FROM
		producto p
		LEFT JOIN (
		SELECT
			md.producto_id,
			sum( md.cantidad ) AS cantidad 
		FROM
			movimiento_detalle md
			INNER JOIN movimiento m ON m.movimiento_id = md.movimiento_id
			INNER JOIN almacen a ON m.almacen_id = a.almacen_id 
		WHERE
			m.estado = 1 
			AND m.numero > 0 
			AND a.local_id = p_local 
		AND
		CASE
				p_lapse 
				WHEN 'week' THEN
				yearweek( m.fecha ) = yearweek( convert_tz( CURDATE( ), 'UTC', 'America/Lima' ) ) 
				WHEN 'month' THEN
				MONTH ( m.fecha ) = MONTH (
				CONVERT_TZ( CURDATE(), 'UTC', 'America/Lima' )) 
				WHEN 'year' THEN
				YEAR ( m.fecha ) = YEAR (
				CONVERT_TZ( CURDATE(), 'UTC', 'America/Lima' )) 
				WHEN 'all' THEN
				1 = 1 
			END 
			GROUP BY
				md.producto_id 
			) m ON p.producto_id = m.producto_id 
		WHERE
			p.tipo_id = 2 
			AND p.estado = 1 
	ORDER BY
		cantidad, p.descripcion;
END;

