create
    definer = c3_admin@`%` procedure sp_caja_info(IN p_local char(36), IN p_apertura datetime, IN p_cierre datetime)
BEGIN
	SELECT
		CASE
			WHEN serie LIKE 'B0%' THEN 'BOLETA' 
			WHEN serie LIKE 'F0%' THEN 'FACTURA'
			ELSE 'TICKET' END AS tipo,
		serie,
		min( cast( numero AS INT ) ) AS inicio,
		max( cast( numero AS INT ) ) AS fin,
		sum(CASE WHEN m.tipo_pago = 1 THEN md.precio_total - ( md.precio_total * IFNULL( m.descuento, 0 ) / 100 ) ELSE 0 END) AS total_efectivo,
		sum(CASE WHEN m.tipo_pago = 2 THEN md.precio_total - ( md.precio_total * IFNULL( m.descuento, 0 ) / 100 ) ELSE 0 END) AS total_credito
	FROM
		movimiento m
		INNER JOIN movimiento_detalle md ON md.movimiento_id = m.movimiento_id AND m.estado = 1
		INNER JOIN almacen a ON a.almacen_id = m.almacen_id
		INNER JOIN `local` l ON l.local_id = a.local_id
	WHERE
		cast( numero AS INT ) > 0 
		AND l.local_id = p_local
		AND m.date_created >= p_apertura 
		AND m.date_created < p_cierre
	GROUP BY m.serie;
END;

