create
    definer = c3_admin@`%` procedure sp_bi_venta_por_dia(IN p_local char(36))
BEGIN
	SELECT
		td.DAY AS dia,
		SUM( IFNULL( v.p_venta, 0 ) ) AS venta 
	FROM
		time_dimension td
		LEFT JOIN vw_descuento v ON td.db_date = v.fecha
		AND v.estado = 1
		AND v.local_id = p_local
	WHERE
		td.YEAR = YEAR ( convert_tz( NOW( ), 'UTC', 'America/Lima' ) ) 
		AND td.MONTH = MONTH ( convert_tz( NOW( ), 'UTC', 'America/Lima' ) ) 
	GROUP BY
		td.DAY 
	ORDER BY
		td.DAY;
END;

