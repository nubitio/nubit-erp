create definer = c3_admin@`%` view vw_reserva as
select `UuidFromBin`(`r`.`reserva_id`) AS `reserva_id`,
       `r`.`local_id`                  AS `local_id`,
       `r`.`numero`                    AS `numero`,
       `r`.`cliente_id`                AS `cliente_id`,
       `r`.`fecha`                     AS `fecha`,
       `r`.`hora`                      AS `hora`,
       `r`.`comesales`                 AS `comesales`,
       `r`.`mesa_id`                   AS `mesa_id`,
       `r`.`observaciones`             AS `observaciones`,
       `r`.`cancelado`                 AS `cancelado`,
       `r`.`created_by`                AS `created_by`,
       `r`.`updated_by`                AS `updated_by`,
       `r`.`created_at`                AS `created_at`,
       `r`.`updated_at`                AS `updated_at`,
       `c`.`razon_social`              AS `cliente`,
       `c`.`telefono`                  AS `telefono`,
       `m`.`descripcion`               AS `mesa`
from ((`c3_efact`.`reserva` `r` join `c3_efact`.`cliente` `c` on (`c`.`ruc` = `r`.`cliente_id`))
         join `c3_efact`.`mesa` `m` on (`m`.`mesa_id` = `r`.`mesa_id`));

