create
    definer = c3_admin@`%` procedure sp_fill_comprobantes()
BEGIN
	INSERT INTO comprobante ( movimiento_id, fecha, tipo_comprobante_id, serie, numero, cliente_id, inafecto, subtotal, igv, total, discount_percent, discount_amount, voided, digest, created_at )
	SELECT
		m.movimiento_id,
		m.fecha,
		0 AS tipo_comprobante_id,
		m.serie,
		m.numero,
		m.cliente_id,
		0 AS inafecto,
		d.v_venta AS subtotal,
		d.igv,
		d.p_venta AS total,
		d.discount_percent AS discount_percent,
		d.discount_amount AS discount_amount,
		d.estado AS voided,
		'' AS digest,
		m.date_created 
	FROM
		movimiento m
		INNER JOIN vw_descuento d ON d.movimiento_id = m.movimiento_id
		LEFT JOIN comprobante cp ON cp.serie = m.serie 
		AND cp.numero = m.numero 
	WHERE
		m.numero > 0 
		AND cp.comprobante_id IS NULL 
	ORDER BY
		m.date_created;
	SELECT ROW_COUNT() AS counter;
END;

