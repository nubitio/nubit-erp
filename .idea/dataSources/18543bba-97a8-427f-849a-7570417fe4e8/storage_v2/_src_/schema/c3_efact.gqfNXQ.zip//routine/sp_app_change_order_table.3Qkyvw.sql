create
    definer = c3_admin@`%` procedure sp_app_change_order_table(IN p_order int, IN p_table char(36))
BEGIN
	UPDATE orden 
	SET mesa_origen = mesa_id,
	mesa_id = p_table 
	WHERE
		orden_id = p_order;
END;

