create view vw_saldo as
select `vw_movimiento_detalle`.`producto_id`                                       AS `producto_id`,
       `vw_movimiento_detalle`.`almacen_id`                                        AS `almacen_id`,
       ifnull(sum(case `vw_movimiento_detalle`.`tipo_id`
                      when 1 then `vw_movimiento_detalle`.`cantidad`
                      when 2 then `vw_movimiento_detalle`.`cantidad` * -1 end), 0) AS `saldo`
from `c3_efact`.`vw_movimiento_detalle`
where `vw_movimiento_detalle`.`estado` = 1
group by `vw_movimiento_detalle`.`producto_id`, `vw_movimiento_detalle`.`almacen_id`;

