create view vw_movimiento_detalle as
select `md`.`movimiento_id`   AS `movimiento_id`,
       `m`.`tipo_id`          AS `tipo_id`,
       `m`.`fecha`            AS `fecha`,
       `p`.`producto_id`      AS `producto_id`,
       `p`.`descripcion`      AS `producto`,
       `a`.`almacen_id`       AS `almacen_id`,
       `a`.`descripcion`      AS `almacen`,
       `p`.`categoria_id`     AS `categoria_id`,
       `c`.`descripcion`      AS `categoria`,
       `md`.`cantidad`        AS `cantidad`,
       `md`.`precio_unitario` AS `precio_unitario`,
       `md`.`descuento`       AS `descuento`,
       `md`.`precio_total`    AS `precio_total`,
       `m`.`estado`           AS `estado`
from ((((`c3_efact`.`movimiento_detalle` `md` join `c3_efact`.`movimiento` `m` on (`m`.`movimiento_id` = `md`.`movimiento_id`)) join `c3_efact`.`producto` `p` on (`p`.`producto_id` = `md`.`producto_id`)) join `c3_efact`.`categoria` `c` on (`c`.`categoria_id` = `p`.`categoria_id`))
         join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `m`.`almacen_id`));

