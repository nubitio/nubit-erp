create definer = c3_admin@`%` trigger operacion_fill_uuid
    before insert
    on operacion
    for each row
    IF new.operacion_id IS NULL OR new.operacion_id = '' THEN
	SET new.operacion_id = UUID();
END IF;

