create view vw_operacion as
select `c3_efact`.`operacion`.`operacion_id` AS `operacion_id`,
       `c3_efact`.`operacion`.`descripcion`  AS `descripcion`,
       `c3_efact`.`operacion`.`tipo_id`      AS `tipo_id`,
       case
           when `c3_efact`.`operacion`.`tipo_id` = 1 then 'INGRESO'
           when `c3_efact`.`operacion`.`tipo_id` = 2 then 'SALIDA'
           else '' end                       AS `tipo`,
       `c3_efact`.`operacion`.`estado`       AS `estado`
from `c3_efact`.`operacion`;

