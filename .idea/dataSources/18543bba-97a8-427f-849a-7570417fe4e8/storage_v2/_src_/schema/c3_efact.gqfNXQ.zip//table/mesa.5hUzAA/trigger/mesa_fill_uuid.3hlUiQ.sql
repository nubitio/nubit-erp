create definer = c3_admin@`%` trigger mesa_fill_uuid
    before insert
    on mesa
    for each row
    IF new.mesa_id IS NULL OR new.mesa_id = '' THEN
	SET new.mesa_id = UUID();
END IF;

