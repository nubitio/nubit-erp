create
    definer = c3_admin@`%` procedure sp_get_precios(IN p_producto char(36))
BEGIN
	SELECT
		l.local_id,
		l.descripcion AS `local`,
		ifnull( pl.precio, 0.00 ) AS precio,
		ifnull( pl.activo, 0) as activo
	FROM
		`local` l
		LEFT JOIN producto_local pl ON pl.local_id = l.local_id 
		AND pl.producto_id = p_producto;
END;

