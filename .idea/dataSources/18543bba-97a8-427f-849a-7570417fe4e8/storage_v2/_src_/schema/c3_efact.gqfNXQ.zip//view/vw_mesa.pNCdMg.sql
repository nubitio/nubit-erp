create view vw_mesa as
select `m`.`mesa_id`      AS `mesa_id`,
       `m`.`ambiente_id`  AS `ambiente_id`,
       `m`.`descripcion`  AS `descripcion`,
       `m`.`position`     AS `position`,
       `m`.`estado`       AS `estado`,
       `e`.`empresa_id`   AS `empresa_id`,
       `e`.`razon_social` AS `empresa`,
       `l`.`local_id`     AS `local_id`,
       `l`.`descripcion`  AS `local`,
       `a`.`descripcion`  AS `ambiente`
from (((`c3_efact`.`mesa` `m` join `c3_efact`.`ambiente` `a` on (`m`.`ambiente_id` = `a`.`ambiente_id`)) join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`))
         join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`));

