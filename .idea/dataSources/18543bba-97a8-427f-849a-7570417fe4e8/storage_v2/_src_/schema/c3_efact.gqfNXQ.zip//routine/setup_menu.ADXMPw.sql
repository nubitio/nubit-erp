create
    definer = c3_admin@`%` procedure setup_menu()
BEGIN
	SET FOREIGN_key_checks = 0;
	TRUNCATE menu;
	INSERT INTO menu ( menu_id, orden, descripcion, link, icon )
	VALUES
		( 1, 1, 'Dashboard', 'dashboard', 'fas fa-tachometer-alt' );
	INSERT INTO menu ( menu_id, orden, descripcion, icon )
	VALUES
		( 100, 1, 'Almacen', 'fas fa-inbox' ),
		( 200, 2, 'Ventas', 'fas fa-shopping-cart' ),
		( 300, 3, 'Caja', 'fas fa-money-check-alt' ),
		( 400, 4, 'RRHH', 'fas fa-users-cog' ),
		( 500, 5, 'Contabilidad', 'fas fa-calculator' ),
		( 900, 5, 'Seguridad', 'fas fa-shield-alt' ),
		( 1000, 6, 'Sistema', 'fas fa-cog' ),
		( 2000, 7, 'Developer', 'fas fa-code' );
	INSERT INTO menu ( menu_id, orden, descripcion, link, icon, parent_id )
	VALUES
	-- almacen
	( 101, 1, 'Proveedores', 'proveedor', 'fas fa-truck', 100 ),
	( 103, 2, 'Productos', 'producto', 'fas fa-cube', 100 ),
	( 104, 3, 'Ingresos', 'ingreso', 'fas fa-cloud-download-alt', 100 ),
	( 105, 4, 'Salidas', 'salida', 'fas fa-cloud-upload-alt', 100 ),
	( 106, 5, 'Transferencias', 'transfer', 'fas fa-exchange-alt', 100 ),
	( 107, 6, 'Movimientos', 'movimientos', 'fas fa-history', 100 ),
	-- ventas
	( 202, 1, 'Registro ventas', 'venta', 'fas fa-table', 200 ),
	( 203, 2, 'Consulta ventas', 'venta-consulta', 'fas fa-table', 200 ),
	( 204, 3, 'Clientes', 'cliente', 'fas fa-user', 200 ),
	-- caja
	( 301, 1, 'Registro caja', 'caja', 'fas fa-table', 300 ),
	( 302, 2, 'Consulta caja', 'caja-consulta', 'fas fa-table', 300 ),
	-- rrhh
	( 401, 1, 'Empleados', 'empleado', 'fas fa-table', 400 ),
	( 402, 2, 'Asistencia', 'asistencia', 'fas fa-calendar-day', 400 ),
	-- contabilidad
	( 501, 1, 'Facturacion', 'facturacion', 'fas fa-file-invoice', 500 ),
	( 502, 2, 'Nota de credito', 'nota', 'fas fa-file-invoice', 500 ),
	-- seguridad
	( 901, 1, 'Usuarios', 'usuario', 'fas fa-user', 900 ),
	( 902, 2, 'Roles', 'rol', 'fas fa-tag', 900 ),
	-- sistema
	( 1001, 1, 'Empresas', 'empresa', 'fas fa-building', 1000 ),
	( 1002, 2, 'Locales', 'local', 'fas fa-home', 1000 ),
	( 1003, 3, 'Almacenes', 'almacen', 'fas fa-table', 1000 ),
	( 1006, 4, 'Categorias', 'categoria', 'fas fa-tags', 1000 ),
	( 1007, 5, 'Unidades', 'unidad', 'fas fa-thermometer', 1000 ),
	( 1008, 6, 'Transacciones', 'operacion', 'fas fa-retweet', 1000 ),
	( 1009, 7, 'Tipo comprobante', 'tipo-comprobante', 'fas fa-receipt', 1000 ),
	( 1010, 8, 'Local comprobante', 'local-comprobante', 'fas fa-file-invoice', 1000 ),
	-- developer
	( 2001, 1, 'Menus', 'menu', 'fas fa-table', 2000 ),
	( 2002, 2, 'Permisos', 'permiso', 'fas fa-tags', 2000 ),
	( 2003, 3, 'Options', 'option', 'fas fa-cog', 2000 );
	SET FOREIGN_key_checks = 1;
END;

