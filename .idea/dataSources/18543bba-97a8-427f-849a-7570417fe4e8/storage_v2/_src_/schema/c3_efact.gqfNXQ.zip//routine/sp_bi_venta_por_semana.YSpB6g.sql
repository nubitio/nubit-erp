create
    definer = c3_admin@`%` procedure sp_bi_venta_por_semana(IN p_local char(36))
BEGIN
	SELECT
		td.day_name AS dia,
		sum( ifnull( v.p_venta, 0 ) ) AS venta 
	FROM
		time_dimension td
		LEFT JOIN vw_descuento v ON td.db_date = v.fecha
		AND v.estado = 1
		AND v.local_id = p_local
	WHERE
		yearweek( td.db_date ) = yearweek( convert_tz( NOW( ), 'UTC', 'America/Lima' ) ) 
	GROUP BY
		td.db_date;
END;

