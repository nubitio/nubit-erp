create view vw_ambiente as
select `a`.`ambiente_id`  AS `ambiente_id`,
       `a`.`local_id`     AS `local_id`,
       `a`.`descripcion`  AS `descripcion`,
       `a`.`estado`       AS `estado`,
       `e`.`empresa_id`   AS `empresa_id`,
       `e`.`razon_social` AS `empresa`,
       `l`.`descripcion`  AS `local`
from ((`c3_efact`.`ambiente` `a` join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`))
         join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`));

