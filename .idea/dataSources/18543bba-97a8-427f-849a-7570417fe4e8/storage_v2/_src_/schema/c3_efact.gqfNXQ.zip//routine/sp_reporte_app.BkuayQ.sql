create
    definer = c3_admin@`%` procedure sp_reporte_app(IN p_local char(36), IN p_fecha date)
BEGIN
	DECLARE
		v_empresa VARCHAR ( 100 );
	DECLARE
		v_local VARCHAR ( 100 );
	DECLARE
		v_almacen CHAR ( 36 );
	SELECT
		e.razon_social,
		l.descripcion,
		a.almacen_id
	INTO
		v_empresa,
		v_local,
		v_almacen
	FROM
		`local` l
		INNER JOIN almacen a ON a.local_id = l.local_id
		INNER JOIN empresa e ON e.empresa_id = l.empresa_id
	WHERE
		l.local_id = p_local and a.is_default = 1
	LIMIT 1;
	SELECT
		DATE_FORMAT( db_date, '%d/%m/%Y' ) AS fecha,
		UPPER(v_empresa) AS razon_social,
		'HALL PRINCIPAL' AS ubicacion,
		'FOOD & BEVERAGE' AS descripcion_del_servicio,
		COUNT( DISTINCT m.movimiento_id ) AS transacciones,
		'SOLES' AS moneda,
		ROUND(SUM((CASE WHEN m.estado = 1 THEN md.precio_total - (md.precio_total * IFNULL(m.descuento, 0) / 100) ELSE 0 END)/1.18),2) AS ventas_sin_igv,
		UPPER(v_local) AS sede 
	FROM
		time_dimension td
		LEFT JOIN movimiento m ON m.fecha = td.db_date 
		AND m.numero > 0 
		AND m.estado = 1
		AND m.almacen_id = v_almacen
		LEFT JOIN movimiento_detalle md ON m.movimiento_id = md.movimiento_id
		LEFT JOIN almacen a ON a.almacen_id = m.almacen_id
	WHERE
		td.MONTH = MONTH ( p_fecha ) 
		AND td.YEAR = YEAR ( p_fecha ) 
	GROUP BY
		td.db_date 
	ORDER BY
		db_date;
	
END;

