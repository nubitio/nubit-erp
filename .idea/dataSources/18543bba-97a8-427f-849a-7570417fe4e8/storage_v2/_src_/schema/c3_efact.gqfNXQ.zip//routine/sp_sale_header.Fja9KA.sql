create
    definer = c3_admin@`%` procedure sp_sale_header(IN p_id char(36))
BEGIN
	SELECT
		m.movimiento_id,
		CASE WHEN LENGTH( c.ruc ) != 11 THEN 1 ELSE 6 END AS client_doc_type,
		c.ruc AS client_doc_number,
		c.razon_social AS client_name,
		c.domicilio_fiscal AS client_address,
		c.email AS client_email,
		e.ruc AS company_id,
		e.razon_social AS company_name,
		e.domicilio_fiscal AS company_address,
		e.telefono AS company_phone,
		CASE WHEN LENGTH( c.ruc ) != 11 THEN '03' ELSE '01' END AS doc_type,
		i.serie AS doc_series,
		i.numero AS doc_number,
		i.fecha AS doc_date,
		'PEN' AS doc_currency,
		i.discount_percent AS doc_discount_percent,
		i.discount_amount AS doc_discount_amount,
		i.subtotal AS doc_taxed_amount,
		i.igv AS doc_igv_amount,
		i.igv AS doc_total_taxes,
		i.subtotal AS doc_sale_value,
		i.total AS doc_sale_amount,
		m.glosa AS doc_notes
	FROM
		movimiento m
		INNER JOIN comprobante i ON i.movimiento_id = m.movimiento_id
		INNER JOIN almacen a ON a.almacen_id = m.almacen_id
		INNER JOIN `local` l ON l.local_id = a.local_id
		INNER JOIN empresa e ON e.empresa_id = l.empresa_id
		INNER JOIN cliente c ON c.ruc = m.cliente_id
	WHERE
			m.movimiento_id = p_id;
END;

