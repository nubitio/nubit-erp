create
    definer = c3_admin@`%` procedure sp_menu_by_rol(IN p_rol int)
BEGIN
	SELECT
		m.menu_id,
		m.descripcion,
		m.parent_id,
		ifnull( mr.estado, 0 ) AS checked 
	FROM
		menu m
		LEFT JOIN menu_rol mr ON m.menu_id = mr.menu_id 
		AND mr.rol_id = p_rol 
	ORDER BY
		m.menu_id,
		m.orden;
END;

