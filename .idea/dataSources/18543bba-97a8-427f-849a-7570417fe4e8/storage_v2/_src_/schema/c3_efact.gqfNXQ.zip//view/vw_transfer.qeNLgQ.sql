create view vw_transfer as
select `UuidFromBin`(`t`.`transfer_id`) AS `transfer_id`,
       `t`.`fecha`                      AS `fecha`,
       `t`.`almacen_origen`             AS `almacen_origen`,
       `t`.`almacen_destino`            AS `almacen_destino`,
       `t`.`nota`                       AS `nota`,
       `t`.`salida_id`                  AS `salida_id`,
       `t`.`ingreso_id`                 AS `ingreso_id`,
       `t`.`created_by`                 AS `created_by`,
       `t`.`updated_by`                 AS `updated_by`,
       `t`.`created_at`                 AS `created_at`,
       `t`.`updated_at`                 AS `updated_at`,
       `o`.`descripcion`                AS `origen`,
       `d`.`descripcion`                AS `destino`
from ((`c3_efact`.`transfer` `t` join `c3_efact`.`almacen` `o` on (`o`.`almacen_id` = `t`.`almacen_origen`))
         join `c3_efact`.`almacen` `d` on (`d`.`almacen_id` = `t`.`almacen_destino`));

