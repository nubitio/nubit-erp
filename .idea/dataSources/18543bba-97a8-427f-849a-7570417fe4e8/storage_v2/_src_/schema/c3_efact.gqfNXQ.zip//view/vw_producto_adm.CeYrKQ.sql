create view vw_producto_adm as
select `p`.`producto_id`                                                                            AS `producto_id`,
       `p`.`codigo`                                                                                 AS `codigo`,
       `p`.`tipo_id`                                                                                AS `tipo_id`,
       `p`.`descripcion`                                                                            AS `descripcion`,
       `p`.`categoria_id`                                                                           AS `categoria_id`,
       `p`.`unidad_id`                                                                              AS `unidad_id`,
       `p`.`destino_id`                                                                             AS `destino_id`,
       `p`.`stock_minimo`                                                                           AS `stock_minimo`,
       `p`.`precio`                                                                                 AS `precio`,
       `p`.`precio_compra`                                                                          AS `precio_compra`,
       `p`.`estado`                                                                                 AS `estado`,
       `c`.`descripcion`                                                                            AS `categoria`,
       case when `p`.`tipo_id` = 1 then 'INSUMO' when `p`.`tipo_id` = 2 then 'VENDIBLE' else '' end AS `tipo`,
       case
           when `p`.`destino_id` = 1 then 'COCINA'
           when `p`.`destino_id` = 2 then 'BARRA'
           when `p`.`destino_id` = 3 then 'COCINA/BARRA'
           when `p`.`destino_id` = 4 then 'VITRINA'
           else '' end                                                                              AS `destino`
from (`c3_efact`.`producto` `p`
         join `c3_efact`.`categoria` `c` on (`c`.`categoria_id` = `p`.`categoria_id`));

