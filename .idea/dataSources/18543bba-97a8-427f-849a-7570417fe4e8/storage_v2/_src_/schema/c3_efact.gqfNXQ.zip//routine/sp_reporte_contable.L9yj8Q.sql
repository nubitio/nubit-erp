create
    definer = c3_admin@`%` procedure sp_reporte_contable(IN p_fecha_desde date, IN p_fecha_hasta date, IN p_local char(36))
BEGIN
	SELECT
		m.fecha,
		m.serie,
		m.numero,
		CASE WHEN m.tipo_pago = 1 THEN'EFECTIVO' ELSE 'TARJETA' END AS tipo_pago,
		c.ruc,
		c.razon_social,
		d.v_venta,
		d.igv,
		d.p_venta,
		d.discount_percent AS descuento,
		u.username as usuario,
		CASE WHEN m.estado = 2 THEN 'ANULADO' ELSE 'PROCESADO' END AS estado 
	FROM
		vw_descuento d
		INNER JOIN movimiento m ON m.movimiento_id = d.movimiento_id
		INNER JOIN almacen a on m.almacen_id = a.almacen_id
		INNER JOIN `local` l on a.local_id = l.local_id
		LEFT JOIN cliente c ON c.ruc = m.cliente_id
		LEFT JOIN orden o ON o.orden_id = m.orden_id
		LEFT JOIN usuario u ON u.usuario_id = o.usuario_id 
	WHERE
		m.numero > 0 
		AND ( m.fecha BETWEEN p_fecha_desde AND p_fecha_hasta ) AND l.local_id = p_local
	ORDER BY
		m.date_created;
END;

