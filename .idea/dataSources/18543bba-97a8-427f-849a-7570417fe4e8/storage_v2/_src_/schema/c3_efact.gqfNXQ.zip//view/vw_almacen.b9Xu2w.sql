create definer = c3_admin@`%` view vw_almacen as
select `a`.`almacen_id`                                                AS `almacen_id`,
       `a`.`local_id`                                                  AS `local_id`,
       `a`.`descripcion`                                               AS `descripcion`,
       `a`.`tipo_id`                                                   AS `tipo_id`,
       `a`.`estado`                                                    AS `estado`,
       case when `a`.`tipo_id` = 1 then 'INSUMOS' else 'PRODUCTOS' end AS `tipo`,
       `e`.`empresa_id`                                                AS `empresa_id`,
       `e`.`razon_social`                                              AS `empresa`,
       `l`.`descripcion`                                               AS `local`
from ((`c3_efact`.`almacen` `a` join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`))
         join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`));

