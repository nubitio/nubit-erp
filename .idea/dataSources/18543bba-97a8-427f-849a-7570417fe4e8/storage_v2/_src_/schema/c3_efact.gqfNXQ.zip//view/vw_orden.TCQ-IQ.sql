create definer = c3_admin@`%` view vw_orden as
select `o`.`orden_id`                   AS `orden_id`,
       `o`.`fecha`                      AS `fecha`,
       `o`.`mesa_id`                    AS `mesa_id`,
       `o`.`nota`                       AS `nota`,
       `o`.`estado_cocina`              AS `estado_cocina`,
       `o`.`estado_barra`               AS `estado_barra`,
       `o`.`estado`                     AS `estado`,
       `m`.`descripcion`                AS `mesa`,
       ifnull(`u`.`username`, 'caja')   AS `mozo`,
       `o`.`anulado`                    AS `anulado`,
       cast(`o`.`date_created` as time) AS `hora_create`,
       cast(`o`.`date_updated` as time) AS `hora_update`,
       `uc`.`username`                  AS `user_create`,
       `uu`.`username`                  AS `user_update`
from ((((`c3_efact`.`orden` `o` join `c3_efact`.`mesa` `m` on (`m`.`mesa_id` = `o`.`mesa_id`)) left join `c3_efact`.`usuario` `u` on (`o`.`usuario_id` = `u`.`usuario_id`)) left join `c3_efact`.`usuario` `uc` on (`o`.`user_create` = `uc`.`usuario_id`))
         left join `c3_efact`.`usuario` `uu` on (`o`.`user_update` = `uu`.`usuario_id`));

