create
    definer = c3_admin@`%` procedure sp_reporte_movimientos(IN p_almacen char(36), IN p_categoria char(36),
                                                            IN p_fi date, IN p_ff date)
BEGIN
	SELECT 
		p.producto_id,
		p.tipo_id,
		p.descripcion AS producto,
		@saldo:=IFNULL(s.saldo, 0.000) AS saldo,
		@ingresos:=IFNULL(k.ingresos, 0.000) AS ingresos,
		@salidas:=IFNULL(k.salidas, 0.000) AS salidas,
		ROUND(IFNULL((@saldo + @ingresos - @salidas), 0.000), 3) AS stock
	FROM
		producto p
			LEFT JOIN
		(SELECT 
			producto_id,
				SUM(CASE tipo_id
					WHEN 1 THEN cantidad
					WHEN 2 THEN cantidad * - 1
				END) AS saldo
		FROM
			vw_movimiento_detalle
		WHERE
			fecha < p_fi AND estado = 1
				AND CASE
				WHEN p_almacen IS NOT NULL THEN almacen_id = p_almacen
				ELSE 1 = 1
			END
		GROUP BY producto_id) s ON s.producto_id = p.producto_id
			LEFT JOIN
		(SELECT 
			producto_id,
				SUM(CASE
					WHEN tipo_id = 1 THEN cantidad
					ELSE 0
				END) AS ingresos,
				SUM(CASE
					WHEN tipo_id = 2 THEN cantidad
					ELSE 0
				END) AS salidas
		FROM
			vw_movimiento_detalle
		WHERE
			fecha BETWEEN p_fi AND p_ff
				AND estado = 1
				AND CASE
				WHEN p_almacen IS NOT NULL THEN almacen_id = p_almacen
				ELSE 1 = 1
			END
		GROUP BY producto_id) k ON k.producto_id = p.producto_id
	WHERE
		CASE
			WHEN p_categoria IS NOT NULL THEN p.categoria_id = p_categoria
			ELSE 1 = 1
		END 
	ORDER BY producto;
END;

