create definer = c3_admin@`%` trigger producto_fill_uuid
    before insert
    on producto
    for each row
    IF new.producto_id IS NULL OR new.producto_id = '' THEN
	SET new.producto_id = UUID();
END IF;

