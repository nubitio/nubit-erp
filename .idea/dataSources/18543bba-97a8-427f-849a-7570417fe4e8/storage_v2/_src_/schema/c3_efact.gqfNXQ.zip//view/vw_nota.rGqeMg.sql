create definer = c3_admin@`%` view vw_nota as
select `n`.`nota_id`                          AS `nota_id`,
       `n`.`movimiento_id`                    AS `movimiento_id`,
       `n`.`fecha`                            AS `fecha`,
       `n`.`tipo_id`                          AS `tipo_id`,
       `n`.`codigo_motivo`                    AS `codigo_motivo`,
       `n`.`descripcion_motivo`               AS `descripcion_motivo`,
       `n`.`serie`                            AS `serie`,
       `n`.`correlativo`                      AS `correlativo`,
       `n`.`digest`                           AS `digest`,
       `n`.`envio_sunat`                      AS `envio_sunat`,
       `n`.`mensaje_sunat`                    AS `mensaje_sunat`,
       `n`.`created_by`                       AS `created_by`,
       `n`.`updated_by`                       AS `updated_by`,
       `n`.`created_at`                       AS `created_at`,
       `n`.`updated_at`                       AS `updated_at`,
       concat(`m`.`serie`, '-', `m`.`numero`) AS `doc_afectado`
from (`c3_efact`.`nota` `n`
         join `c3_efact`.`movimiento` `m` on (`m`.`movimiento_id` = `n`.`movimiento_id`));

