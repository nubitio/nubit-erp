create definer = c3_admin@`%` trigger ambiente_fill_uuid
    before insert
    on ambiente
    for each row
    IF new.ambiente_id IS NULL OR new.ambiente_id = '' THEN
	SET new.ambiente_id = UUID();
END IF;

