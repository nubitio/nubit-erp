create definer = c3_admin@`%` trigger local_fill_uuid
    before insert
    on local
    for each row
    IF new.local_id IS NULL OR new.local_id = '' THEN
	SET new.local_id=UUID();
END IF;

