create
    definer = c3_admin@`%` procedure sp_make_invoice(IN p_movimiento char(36), IN p_local char(36))
BEGIN
	INSERT INTO comprobante (
		movimiento_id,
		fecha,
		tipo_comprobante_id,
		serie,
		numero,
		cliente_id,
		inafecto,
		subtotal,
		igv,
		total,
		discount_percent,
		discount_amount,
		voided,
		created_at 
	) 
	SELECT
		m.movimiento_id,
		CURDATE() as fecha,
		CASE
				
				WHEN LENGTH( m.cliente_id ) != 11 THEN
				'03' ELSE '01' 
			END AS tipo_comprobante_id,
			lc.serie,
			( SELECT ifnull( max( cast( numero AS INT ) ), 0 ) AS numero FROM comprobante WHERE serie = lc.serie ) + 1 AS numero,
			m.cliente_id,
			0 AS inafecto,
			d.v_venta AS subtotal,
			d.igv,
			d.p_venta AS total,
			d.discount_percent AS discount_percent,
			d.discount_amount AS discount_amount,
			d.estado AS voided,
			m.date_created 
		FROM
			movimiento m
			INNER JOIN vw_descuento d ON d.movimiento_id = m.movimiento_id
			INNER JOIN almacen a ON a.almacen_id = m.almacen_id
			INNER JOIN local_comprobante lc ON lc.local_id = a.local_id
			LEFT JOIN comprobante cp ON cp.movimiento_id = m.movimiento_id 
		WHERE
			m.movimiento_id = p_movimiento 
			AND a.local_id = p_local 
			AND lc.tipo_comprobante_id =
		CASE
				
				WHEN LENGTH( m.cliente_id ) != 11 THEN
				'03' ELSE '01' 
			END 
				AND cp.comprobante_id IS NULL 
			ORDER BY
				m.date_created;
	SELECT ROW_COUNT() AS counter;
END;

