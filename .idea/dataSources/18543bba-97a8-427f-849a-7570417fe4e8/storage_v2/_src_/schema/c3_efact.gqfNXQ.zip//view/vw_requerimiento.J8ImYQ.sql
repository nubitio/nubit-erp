create definer = c3_admin@`%` view vw_requerimiento as
select `r`.`requerimiento_id` AS `requerimiento_id`,
       `r`.`fecha`            AS `fecha`,
       `r`.`almacen_id`       AS `almacen_id`,
       `r`.`estado`           AS `estado`,
       `a`.`descripcion`      AS `almacen`
from (`c3_efact`.`requerimiento` `r`
         join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `r`.`almacen_id`));

