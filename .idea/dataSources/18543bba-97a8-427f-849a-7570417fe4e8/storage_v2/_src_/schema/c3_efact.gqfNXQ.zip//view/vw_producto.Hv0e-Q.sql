create definer = c3_admin@`%` view vw_producto as
select `p`.`producto_id`                                                                            AS `producto_id`,
       `p`.`codigo`                                                                                 AS `codigo`,
       `p`.`tipo_id`                                                                                AS `tipo_id`,
       `p`.`descripcion`                                                                            AS `descripcion`,
       `p`.`categoria_id`                                                                           AS `categoria_id`,
       `p`.`unidad_id`                                                                              AS `unidad_id`,
       `p`.`destino_id`                                                                             AS `destino_id`,
       `p`.`stock_minimo`                                                                           AS `stock_minimo`,
       `p`.`precio`                                                                                 AS `precio`,
       `p`.`estado`                                                                                 AS `estado`,
       `l`.`local_id`                                                                               AS `local_id`,
       `l`.`descripcion`                                                                            AS `local`,
       `l`.`descripcion`                                                                            AS `local_name`,
       `c`.`descripcion`                                                                            AS `categoria`,
       `u`.`descripcion`                                                                            AS `unidad`,
       case when `p`.`tipo_id` = 1 then 'INSUMO' when `p`.`tipo_id` = 2 then 'VENDIBLE' else '' end AS `tipo`,
       case
           when `p`.`destino_id` = 1 then 'COCINA'
           when `p`.`destino_id` = 2 then 'BARRA'
           when `p`.`destino_id` = 3 then 'COCINA/BARRA'
           else '' end                                                                              AS `destino`,
       sum(ifnull(`e`.`saldo`, 0))                                                                  AS `stock`
from (((((`c3_efact`.`producto` `p` join `c3_efact`.`categoria` `c` on (`c`.`categoria_id` = `p`.`categoria_id`)) left join `c3_efact`.`producto_local` `pl` on (`pl`.`producto_id` = `p`.`producto_id`)) left join `c3_efact`.`local` `l` on (`l`.`local_id` = `pl`.`local_id`)) left join `c3_efact`.`unidad` `u` on (`u`.`unidad_id` = `p`.`unidad_id`))
         left join `c3_efact`.`vw_saldo` `e` on (`e`.`producto_id` = `p`.`producto_id`))
group by `p`.`producto_id`, `l`.`local_id`;

