create view vw_menu as
select `m`.`menu_id`     AS `menu_id`,
       `m`.`orden`       AS `orden`,
       `m`.`descripcion` AS `descripcion`,
       `m`.`link`        AS `link`,
       `m`.`icon`        AS `icon`,
       `m`.`parent_id`   AS `parent_id`,
       `p`.`descripcion` AS `padre`
from (`c3_efact`.`menu` `m`
         left join `c3_efact`.`menu` `p` on (`m`.`parent_id` = `p`.`menu_id`));

