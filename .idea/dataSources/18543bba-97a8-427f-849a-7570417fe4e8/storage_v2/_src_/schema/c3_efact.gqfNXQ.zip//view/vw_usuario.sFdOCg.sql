create definer = c3_admin@`%` view vw_usuario as
select `u`.`usuario_id`  AS `usuario_id`,
       `u`.`email`       AS `email`,
       `u`.`password`    AS `password`,
       `u`.`rol_id`      AS `rol_id`,
       `u`.`roles`       AS `roles`,
       `u`.`username`    AS `username`,
       `u`.`phone`       AS `phone`,
       `u`.`pin`         AS `pin`,
       `u`.`active`      AS `active`,
       `r`.`descripcion` AS `rol`
from (`c3_efact`.`usuario` `u`
         join `c3_efact`.`rol` `r` on (`r`.`rol_id` = `u`.`rol_id`))
where `u`.`username` <> 'root';

