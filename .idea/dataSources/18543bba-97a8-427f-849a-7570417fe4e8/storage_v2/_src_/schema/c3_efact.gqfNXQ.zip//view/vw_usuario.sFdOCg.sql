create definer = c3_admin@`%` view vw_usuario as
select `u`.`usuario_id`   AS `usuario_id`,
       `u`.`username`     AS `username`,
       `u`.`password`     AS `password`,
       `u`.`pin`          AS `pin`,
       `u`.`rol_id`       AS `rol_id`,
       `u`.`estado`       AS `estado`,
       `u`.`date_created` AS `date_created`,
       `u`.`date_updated` AS `date_updated`,
       `r`.`descripcion`  AS `rol`
from (`c3_efact`.`usuario` `u`
         join `c3_efact`.`rol` `r` on (`r`.`rol_id` = `u`.`rol_id`))
where `u`.`username` <> 'root';

