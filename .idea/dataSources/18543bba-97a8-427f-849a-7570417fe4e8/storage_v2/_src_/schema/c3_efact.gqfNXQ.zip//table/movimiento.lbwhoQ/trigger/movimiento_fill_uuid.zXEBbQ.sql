create definer = c3_admin@`%` trigger movimiento_fill_uuid
    before insert
    on movimiento
    for each row
    IF new.movimiento_id IS NULL OR new.movimiento_id = '' THEN
	SET new.movimiento_id = UUID();
END IF;

