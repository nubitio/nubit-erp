create
    definer = c3_admin@`%` procedure sp_kardex(IN p_almacen char(36), IN p_producto char(36), IN p_fi date,
                                               IN p_ff date)
BEGIN
	SELECT 
		m.fecha,
		CASE m.tipo_id
			WHEN 1 THEN 'INGRESO'
			WHEN 2 THEN 'SALIDA'
			ELSE ''
		END AS tipo_id,
		a.descripcion AS almacen,
		o.descripcion AS operacion,
		md.cantidad
	FROM
		movimiento_detalle md
			INNER JOIN
		movimiento m ON m.movimiento_id = md.movimiento_id
			INNER JOIN
		producto p ON p.producto_id = md.producto_id
			INNER JOIN
		almacen a ON a.almacen_id = m.almacen_id
			INNER JOIN
		operacion o ON o.operacion_id = m.operacion_id
	WHERE
		m.estado = 1
			AND CASE
			WHEN p_almacen IS NOT NULL THEN m.almacen_id = p_almacen
			ELSE 1 = 1
		END
			AND md.producto_id = p_producto
			AND m.fecha BETWEEN p_fi AND p_ff
	ORDER BY m.date_created DESC;
END;

