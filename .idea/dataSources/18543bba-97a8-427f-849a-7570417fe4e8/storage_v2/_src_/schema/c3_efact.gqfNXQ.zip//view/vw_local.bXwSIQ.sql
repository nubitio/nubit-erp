create view vw_local as
select `l`.`local_id`     AS `local_id`,
       `l`.`empresa_id`   AS `empresa_id`,
       `l`.`descripcion`  AS `descripcion`,
       `l`.`direccion`    AS `direccion`,
       `l`.`telefono`     AS `telefono`,
       `l`.`estado`       AS `estado`,
       `e`.`razon_social` AS `empresa`
from (`c3_efact`.`local` `l`
         join `c3_efact`.`empresa` `e` on (`e`.`empresa_id` = `l`.`empresa_id`));

