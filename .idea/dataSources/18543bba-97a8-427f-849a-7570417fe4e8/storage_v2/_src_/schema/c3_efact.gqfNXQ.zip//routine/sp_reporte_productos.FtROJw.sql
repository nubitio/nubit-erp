create
    definer = c3_admin@`%` procedure sp_reporte_productos(IN p_local char(36))
select
    p.descripcion,
    c.descripcion as categoria,
    case p.destino_id
    when 1
      then 'COCINA'
    when 2
      then 'BARRA'
    when 3
      then 'COCINA/BARRA'
    else '' end   as destino,
    p.precio,
    case p.estado
    when 1
      then 'ACTIVO'
    when 2
      then 'INACTIVO'
    else '' end   as estado
  from
    producto p
		inner join producto_local pl on pl.producto_id = p.producto_id and pl.local_id = p_local
    inner join categoria c on c.categoria_id = p.categoria_id
  where p.tipo_id = 2
  group by
    p.producto_id
  order by p.descripcion;

