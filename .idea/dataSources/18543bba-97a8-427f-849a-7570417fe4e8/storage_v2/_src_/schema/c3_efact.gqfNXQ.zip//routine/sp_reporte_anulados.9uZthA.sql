create
    definer = c3_admin@`%` procedure sp_reporte_anulados(IN p_fecha_desde date, IN p_fecha_hasta date)
BEGIN
	
	SELECT
	m.fecha,
	o.descripcion AS operacion,
	c.ruc,
	c.razon_social,
	m.serie,
	m.numero,
	m.glosa AS obs 
FROM
	movimiento m
	INNER JOIN operacion o ON o.operacion_id = m.operacion_id
	INNER JOIN cliente c ON c.ruc = m.cliente_id 
WHERE
	m.numero IS NOT NULL 
	AND m.estado =2 AND fecha BETWEEN p_fecha_desde AND p_fecha_hasta;
END;

