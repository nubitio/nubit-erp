create
    definer = c3_admin@`%` procedure sp_menu_lista(IN p_filtered tinyint(1))
    if p_filtered then
    select
      m.menu_id,
      if(p.descripcion is not null, concat(p.descripcion, '-', m.descripcion), m.descripcion) as descripcion
    from menu m
      left join menu p on p.menu_id = m.parent_id
    where 1=1
    order by descripcion;
  else
    select
      m.menu_id,
      if(p.descripcion is not null, concat(p.descripcion, '-', m.descripcion), m.descripcion) as descripcion
    from menu m
      left join menu p on p.menu_id = m.parent_id
    order by descripcion;
  end if;

