create
    definer = c3_admin@`%` procedure sp_app_select_ambient()
BEGIN
  SELECT
		ambiente_id,
		descripcion 
	FROM
		ambiente 
	WHERE
		estado =1;
END;

