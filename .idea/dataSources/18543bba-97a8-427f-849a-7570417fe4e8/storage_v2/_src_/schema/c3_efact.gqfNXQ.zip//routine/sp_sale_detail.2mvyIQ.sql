create
    definer = c3_admin@`%` procedure sp_sale_detail(IN p_id char(36))
BEGIN
	SELECT
		p.producto_id AS product_id,
		p.codigo AS `code`,
		p.descripcion AS product,
		dd.cantidad AS quantity,
		dd.p_unitario AS price,
		dd.p_venta AS total,
		'10' AS tax_type
	FROM movimiento m
	INNER JOIN vw_descuento_detalle dd ON dd.movimiento_id = m.movimiento_id
	INNER JOIN producto p ON p.producto_id = dd.producto_id
	WHERE m.movimiento_id = p_id;
END;

