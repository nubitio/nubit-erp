create
    definer = c3_admin@`%` procedure sp_get_saldo(IN p_almacen char(36), IN p_producto char(36), IN p_fecha date)
SELECT
	producto,
	ifnull( SUM( CASE tipo_id WHEN 1 THEN cantidad WHEN 2 THEN cantidad * - 1 END ), 0 ) AS saldo 
FROM
	vw_movimiento_detalle 
WHERE
	almacen_id = p_almacen 
	AND producto_id = p_producto 
	AND fecha < p_fecha 
	AND estado = 1;

