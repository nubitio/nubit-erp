create definer = c3_admin@`%` view vw_kardex as
select `m`.`fecha`                                                 AS `fecha`,
       `l`.`local_id`                                              AS `local_id`,
       `a`.`almacen_id`                                            AS `almacen_id`,
       `md`.`producto_id`                                          AS `producto_id`,
       `o`.`descripcion`                                           AS `operacion`,
       case when `m`.`tipo_id` = 1 then `md`.`cantidad` else 0 end AS `ingresos`,
       case when `m`.`tipo_id` = 2 then `md`.`cantidad` else 0 end AS `salidas`,
       `m`.`date_created`                                          AS `date_created`
from ((((`c3_efact`.`movimiento_detalle` `md` join `c3_efact`.`movimiento` `m` on (`m`.`movimiento_id` = `md`.`movimiento_id`)) join `c3_efact`.`operacion` `o` on (`o`.`operacion_id` = `m`.`operacion_id`)) join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `m`.`almacen_id`))
         join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`))
where `m`.`estado` = 1
order by `m`.`date_created`;

