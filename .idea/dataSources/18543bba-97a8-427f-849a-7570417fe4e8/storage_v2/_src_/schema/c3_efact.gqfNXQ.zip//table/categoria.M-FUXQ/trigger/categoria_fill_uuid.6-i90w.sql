create definer = c3_admin@`%` trigger categoria_fill_uuid
    before insert
    on categoria
    for each row
    IF new.categoria_id IS NULL OR new.categoria_id = '' THEN
	SET new.categoria_id = UUID();
END IF;

