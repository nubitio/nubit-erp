create
    definer = c3_admin@`%` procedure sp_notify(IN p_date date)
BEGIN
	SELECT
		td.db_date AS fecha,
		l.descripcion AS `local`,
		lc.serie,
		m.desde,
		m.hasta,
		m.comprobantes,
		m.hora_max AS hora_ultimo 
	FROM
		time_dimension td
		CROSS JOIN `local` l
		INNER JOIN local_comprobante lc ON lc.local_id = l.local_id
		LEFT JOIN (
		SELECT
			serie,
			min( numero ) AS desde,
			min( time( date_created ) ) AS hora_min,
			max( numero ) AS hasta,
			max( time( date_created ) ) AS hora_max,
			count( movimiento_id ) AS comprobantes 
		FROM
			movimiento 
		WHERE
			fecha = p_date
			AND numero > 0 
		GROUP BY
			serie 
		) m ON m.serie = lc.serie 
	WHERE
		date( td.db_date ) = p_date
	GROUP BY
		`local`,
		lc.serie 
	ORDER BY
		`local`,
		serie;
END;

