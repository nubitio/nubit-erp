create definer = c3_admin@`%` trigger comprobante_fill_uuid
    before insert
    on comprobante
    for each row
BEGIN
IF new.comprobante_id IS NULL OR new.comprobante_id = '' THEN
	SET new.comprobante_id = UUID();
END IF;
END;

