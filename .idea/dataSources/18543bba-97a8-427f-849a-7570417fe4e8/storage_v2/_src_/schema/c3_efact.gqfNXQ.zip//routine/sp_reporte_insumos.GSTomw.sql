create
    definer = c3_admin@`%` procedure sp_reporte_insumos()
select
    p.descripcion,
    c.descripcion           as categoria,
    u.descripcion           as unidad,
    sum(ifnull(e.stock, 0)) as stock,
    case when p.estado = 1
      then 'ACTIVO'
    when p.estado = 2
      then 'INACTIVO'
    else '' end             as estado
  from
    producto p
    inner join categoria c on c.categoria_id = p.categoria_id
    left join unidad u on u.unidad_id = p.unidad_id
    left join existencia e on e.producto_id = p.producto_id
  where p.tipo_id = 1
  group by
    p.producto_id
  order by p.descripcion;

