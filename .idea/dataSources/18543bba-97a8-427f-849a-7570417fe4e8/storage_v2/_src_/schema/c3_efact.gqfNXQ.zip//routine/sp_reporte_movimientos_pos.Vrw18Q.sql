create
    definer = c3_admin@`%` procedure sp_reporte_movimientos_pos(IN p_local char(36), IN p_almacen char(36),
                                                                IN p_categoria char(36), IN p_fi date, IN p_ff date)
BEGIN
	SELECT
		p.producto_id,
		p.descripcion AS producto,
		@saldo := IFNULL( s.saldo, 0 ) AS saldo,
		@ingresos := IFNULL( k.ingresos, 0 ) AS ingresos,
		@salidas := IFNULL( k.salidas, 0 ) AS salidas,
		ROUND( IFNULL(( @saldo + @ingresos - @salidas ), 0 ), 2 ) AS stock 
	FROM
		producto p
		INNER JOIN producto_local pl ON p.producto_id = pl.producto_id
		LEFT JOIN (
		SELECT
			producto_id,
			SUM( CASE tipo_id WHEN 1 THEN cantidad WHEN 2 THEN cantidad * - 1 END ) AS saldo 
		FROM
			vw_movimiento_detalle 
		WHERE
			fecha < p_fi 
			AND estado = 1 
		AND
		CASE
				
				WHEN p_almacen IS NOT NULL THEN
				almacen_id = p_almacen ELSE 1 = 1 
			END 
			GROUP BY
				producto_id 
			) s ON s.producto_id = p.producto_id
			LEFT JOIN (
			SELECT
				producto_id,
				SUM( CASE WHEN tipo_id = 1 THEN cantidad ELSE 0 END ) AS ingresos,
				SUM( CASE WHEN tipo_id = 2 THEN cantidad ELSE 0 END ) AS salidas 
			FROM
				vw_movimiento_detalle 
			WHERE
				fecha BETWEEN p_fi 
				AND p_ff 
				AND estado = 1 
			AND
			CASE
					
					WHEN p_almacen IS NOT NULL THEN
					almacen_id = p_almacen ELSE 1 = 1 
				END 
				GROUP BY
					producto_id 
				) k ON k.producto_id = p.producto_id 
			WHERE
				pl.local_id = p_local 
			AND
			CASE
					WHEN p_categoria IS NOT NULL THEN
					p.categoria_id = p_categoria ELSE 1 = 1 
				END 
					AND p.tipo_id = 2 
			ORDER BY
		producto;
END;

