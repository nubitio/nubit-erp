create
    definer = c3_admin@`%` procedure sp_select_pending_voided()
BEGIN
	SELECT
		c.* 
	FROM
		comprobante c
		INNER JOIN movimiento m ON c.movimiento_id = m.movimiento_id
		LEFT JOIN nota n ON m.movimiento_id = n.movimiento_id 
	WHERE
		m.estado = 2 
		AND c.envio_sunat = 0
		AND n.movimiento_id IS NULL;
END;

