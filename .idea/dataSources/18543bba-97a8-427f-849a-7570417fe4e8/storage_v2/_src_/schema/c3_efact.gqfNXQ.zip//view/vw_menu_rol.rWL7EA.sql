create definer = c3_admin@`%` view vw_menu_rol as
select `mr`.`menu_id`                                                                                          AS `menu_id`,
       `mr`.`rol_id`                                                                                           AS `rol_id`,
       `mr`.`estado`                                                                                           AS `estado`,
       if(`p`.`descripcion` is not null, concat(`p`.`descripcion`, '-', `m`.`descripcion`),
          `m`.`descripcion`)                                                                                   AS `menu`,
       `r`.`descripcion`                                                                                       AS `rol`
from (((`c3_efact`.`menu` `m` left join `c3_efact`.`menu_rol` `mr` on (`m`.`menu_id` = `mr`.`menu_id`)) left join `c3_efact`.`menu` `p` on (`m`.`parent_id` = `p`.`menu_id`))
         join `c3_efact`.`rol` `r` on (`r`.`rol_id` = `mr`.`rol_id`))
order by `r`.`rol_id`, `m`.`orden`, `m`.`parent_id`;

