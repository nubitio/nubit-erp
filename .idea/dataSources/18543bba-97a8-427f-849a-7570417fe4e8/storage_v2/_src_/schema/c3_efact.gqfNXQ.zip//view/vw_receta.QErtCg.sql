create definer = c3_admin@`%` view vw_receta as
select `r`.`receta_id`    AS `receta_id`,
       `r`.`producto_id`  AS `producto_id`,
       `r`.`estado`       AS `estado`,
       `r`.`user_create`  AS `user_create`,
       `r`.`date_created` AS `date_created`,
       `r`.`user_update`  AS `user_update`,
       `r`.`date_update`  AS `date_update`,
       `p`.`descripcion`  AS `descripcion`
from (`c3_efact`.`receta` `r`
         join `c3_efact`.`producto` `p` on (`p`.`producto_id` = `r`.`producto_id`));

