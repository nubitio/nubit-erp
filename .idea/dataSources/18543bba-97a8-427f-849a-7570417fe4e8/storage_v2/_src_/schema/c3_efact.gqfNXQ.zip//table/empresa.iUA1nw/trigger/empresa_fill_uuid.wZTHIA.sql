create definer = c3_admin@`%` trigger empresa_fill_uuid
    before insert
    on empresa
    for each row
    IF new.empresa_id IS NULL OR new.empresa_id = '' THEN
	SET new.empresa_id=UUID();
END IF;

