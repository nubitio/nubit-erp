create view vw_descuento as
select `m`.`movimiento_id`                                                                                         AS `movimiento_id`,
       `m`.`fecha`                                                                                                 AS `fecha`,
       `l`.`local_id`                                                                                              AS `local_id`,
       `m`.`almacen_id`                                                                                            AS `almacen_id`,
       `m`.`cliente_id`                                                                                            AS `cliente_id`,
       `m`.`serie`                                                                                                 AS `serie`,
       `m`.`numero`                                                                                                AS `numero`,
       round(sum(`md`.`precio_total` / 1.18), 2)                                                                   AS `v_venta`,
       round(sum(`md`.`precio_total` / 1.18 * 0.18), 2)                                                            AS `igv`,
       round(sum(`md`.`precio_total`), 2)                                                                          AS `p_venta`,
       round(sum((`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100) / 1.18),
             2)                                                                                                    AS `dv_venta`,
       round(sum((`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100) / 1.18 * 0.18),
             2)                                                                                                    AS `d_igv`,
       round(sum(`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100),
             2)                                                                                                    AS `dp_venta`,
       `m`.`descuento`                                                                                             AS `discount_percent`,
       round(sum(`md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100),
             2)                                                                                                    AS `discount_amount`,
       `m`.`date_created`                                                                                          AS `date_created`,
       `m`.`estado`                                                                                                AS `estado`
from (((`c3_efact`.`movimiento` `m` join `c3_efact`.`movimiento_detalle` `md` on (`m`.`movimiento_id` = `md`.`movimiento_id`)) join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `m`.`almacen_id`))
         join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`))
where `m`.`numero` > 0
group by `m`.`movimiento_id`
order by `m`.`date_created` desc;

