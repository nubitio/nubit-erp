create
    definer = c3_admin@`%` procedure sp_app_select_tables_by_ambient(IN p_ambient char(36))
BEGIN
  SELECT
		m.mesa_id,
		m.descripcion AS mesa,
		SUM(
		IFNULL( od.precio_total, 0 )) AS total,
		GROUP_CONCAT( od.estado ) AS counter,
		TIME( o.date_created ) AS time,
		IFNULL( MAX( o.estado ), 0 ) AS estado,
		IFNULL( COUNT( r.reserva_id ), 0 ) AS reservas 
	FROM
		mesa m
		INNER JOIN ambiente a ON a.ambiente_id = m.ambiente_id
		LEFT JOIN orden o ON o.mesa_id = m.mesa_id 
		AND o.estado != 3
		LEFT JOIN orden_detalle od ON od.orden_id = o.orden_id
		LEFT JOIN reserva r ON r.mesa_id = m.mesa_id 
		AND r.fecha = DATE(convert_tz( NOW( ), 'UTC', 'America/Lima' )) 
		AND IFNULL( cancelado, 0 ) = 0 
	WHERE
		m.estado = 1 
		AND m.ambiente_id = p_ambient 
	GROUP BY
		m.mesa_id 
	ORDER BY
		m.position;
END;

