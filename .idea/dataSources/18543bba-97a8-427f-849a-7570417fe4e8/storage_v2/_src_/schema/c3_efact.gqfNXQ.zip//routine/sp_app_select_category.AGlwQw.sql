create
    definer = c3_admin@`%` procedure sp_app_select_category()
BEGIN
  SELECT
		categoria_id,
		descripcion 
	FROM
		categoria 
	WHERE
		estado =1;
END;

