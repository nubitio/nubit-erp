create definer = c3_admin@`%` trigger fill_number
    before insert
    on reserva
    for each row
    IF new.numero IS NULL OR new.numero = '' THEN
	SET @last = (SELECT IFNULL(MAX(numero), 0) AS last FROM reserva WHERE local_id = new.local_id);
	SET new.numero=@last + 1;
END IF;

