create
    definer = c3_admin@`%` procedure sp_reporte_asistencia_mensual(IN p_empleado char(8), IN p_desde date, IN p_hasta date)
BEGIN
	SELECT
		dni,
		empleado,
		fecha,
		GROUP_CONCAT( hora ORDER BY hora SEPARATOR '_' ) AS times 
	FROM
		vw_asistencia 
	WHERE
		dni = p_empleado
		AND fecha BETWEEN p_desde AND p_hasta
	GROUP BY
		fecha,
		dni 
	ORDER BY
		dni,
		created_at;
END;

