create definer = c3_admin@`%` view vw_comprobante as
select `a`.`local_id`            AS `local_id`,
       `p`.`comprobante_id`      AS `comprobante_id`,
       `p`.`movimiento_id`       AS `movimiento_id`,
       `p`.`tipo_comprobante_id` AS `tipo_comprobante_id`,
       `p`.`fecha`               AS `fecha`,
       `p`.`serie`               AS `serie`,
       `p`.`numero`              AS `numero`,
       `p`.`cliente_id`          AS `cliente_id`,
       `p`.`inafecto`            AS `inafecto`,
       `p`.`subtotal`            AS `subtotal`,
       `p`.`igv`                 AS `igv`,
       `p`.`total`               AS `total`,
       `p`.`discount_percent`    AS `discount_percent`,
       `p`.`discount_amount`     AS `discount_amount`,
       `p`.`voided`              AS `estado`,
       `p`.`digest`              AS `digest`,
       `p`.`envio_sunat`         AS `envio_sunat`,
       `p`.`mensaje_sunat`       AS `mensaje_sunat`,
       `p`.`created_at`          AS `created_at`,
       `p`.`updated_at`          AS `updated_at`,
       `c`.`razon_social`        AS `cliente`
from (((`c3_efact`.`comprobante` `p` join `c3_efact`.`movimiento` `m` on (`m`.`movimiento_id` = `p`.`movimiento_id`)) join `c3_efact`.`cliente` `c` on (`c`.`ruc` = `p`.`cliente_id`))
         join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `m`.`almacen_id`));

