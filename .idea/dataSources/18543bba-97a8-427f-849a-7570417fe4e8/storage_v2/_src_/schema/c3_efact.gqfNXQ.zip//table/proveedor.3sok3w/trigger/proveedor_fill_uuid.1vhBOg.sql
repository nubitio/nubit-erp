create definer = c3_admin@`%` trigger proveedor_fill_uuid
    before insert
    on proveedor
    for each row
    IF new.proveedor_id IS NULL OR new.proveedor_id = '' THEN
	SET new.proveedor_id = UUID();
END IF;

