create
    definer = c3_admin@`%` procedure sp_reporte_asistencia_resumen(IN p_contrato int, IN p_desde date, IN p_hasta date)
BEGIN
	SELECT
		e.dni,
		CONCAT( e.nombres, ' ', e.apellidos ) AS empleado,
		td.db_date,
		IFNULL( a.times, '' ) AS times 
	FROM
		time_dimension td
		CROSS JOIN empleado e
		LEFT JOIN (
		SELECT
			dni,
			fecha,
			GROUP_CONCAT( hora ORDER BY hora SEPARATOR '_' ) AS times 
		FROM
			vw_asistencia 
		WHERE
			fecha BETWEEN p_desde 
			AND p_hasta 
			AND tipo_contrato = p_contrato 
		GROUP BY
			fecha,
			dni 
		) a ON td.db_date = a.fecha 
		AND e.dni = a.dni 
	WHERE
		td.db_date BETWEEN p_desde 
		AND p_hasta 
	GROUP BY
		td.db_date,
		e.dni 
	ORDER BY
		td.db_date;
END;

