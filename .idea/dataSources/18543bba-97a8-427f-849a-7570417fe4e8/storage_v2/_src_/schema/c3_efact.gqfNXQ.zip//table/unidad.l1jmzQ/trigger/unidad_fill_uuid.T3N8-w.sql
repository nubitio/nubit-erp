create definer = c3_admin@`%` trigger unidad_fill_uuid
    before insert
    on unidad
    for each row
    IF new.unidad_id IS NULL OR new.unidad_id = '' THEN
	SET new.unidad_id = UUID();
END IF;

