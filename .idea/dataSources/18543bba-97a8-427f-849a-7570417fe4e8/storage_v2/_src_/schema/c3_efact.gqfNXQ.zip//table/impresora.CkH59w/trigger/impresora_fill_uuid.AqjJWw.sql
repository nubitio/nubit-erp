create definer = c3_admin@`%` trigger impresora_fill_uuid
    before insert
    on impresora
    for each row
    IF new.impresora_id IS NULL OR new.impresora_id = '' THEN
	SET new.impresora_id = UUID();
END IF;

