create
    definer = c3_admin@`%` procedure sp_reporte_asistencia_diaria(IN p_fecha date)
BEGIN
	SELECT
		dni,
		empleado,
		fecha,
		GROUP_CONCAT( hora ORDER BY hora SEPARATOR '_' ) AS times 
	FROM
		vw_asistencia
	WHERE
		fecha = p_fecha
	GROUP BY
		fecha,
		dni 
	ORDER BY
		dni,
		created_at;
END;

