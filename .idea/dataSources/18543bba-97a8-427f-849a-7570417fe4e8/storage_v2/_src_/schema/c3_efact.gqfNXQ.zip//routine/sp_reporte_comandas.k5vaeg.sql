create
    definer = c3_admin@`%` procedure sp_reporte_comandas(IN p_fecha_inicio date, IN p_fecha_fin date)
BEGIN
	SELECT
	o.orden_id as orden,
	date(o.fecha) as fecha,
	time(od.date_created) as hora,
	o.mesa,
	CASE WHEN p.destino_id = 1 THEN 'COCINA' WHEN p.destino_id = 2 THEN 'BARRA' ELSE 'COCINA/BARRA' END AS destino,
	p.descripcion as producto,
	od.cantidad,
	od.nota
FROM
	vw_orden o
	INNER JOIN orden_detalle od ON od.orden_id = o.orden_id
	INNER JOIN producto p ON p.producto_id = od.producto_id 
WHERE
	date( fecha ) BETWEEN p_fecha_inicio
	AND p_fecha_fin;
END;

