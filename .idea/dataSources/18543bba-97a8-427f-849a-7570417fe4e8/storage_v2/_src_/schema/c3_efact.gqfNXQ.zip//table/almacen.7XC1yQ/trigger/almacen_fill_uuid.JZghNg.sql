create definer = c3_admin@`%` trigger almacen_fill_uuid
    before insert
    on almacen
    for each row
    IF new.almacen_id IS NULL OR new.almacen_id = ''  THEN
	SET new.almacen_id = UUID();
END IF;

