create
    definer = c3_admin@`%` procedure sp_last_sync()
BEGIN
	SELECT
		l.descripcion AS `local`,
		max( date_created ) AS last_sync 
	FROM
		movimiento m
		INNER JOIN almacen a ON a.almacen_id = m.almacen_id
		INNER JOIN `local` l ON l.local_id = a.local_id 
	WHERE
		m.numero > 0 
	GROUP BY
		m.almacen_id 
	ORDER BY
		last_sync DESC;
END;

