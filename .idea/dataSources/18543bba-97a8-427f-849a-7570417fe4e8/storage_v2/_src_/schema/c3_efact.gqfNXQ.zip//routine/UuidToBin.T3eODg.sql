create
    definer = c3_admin@`%` function UuidToBin(_uuid binary(36)) returns binary(16) deterministic security invoker
RETURN UNHEX(
	CONCAT(
		SUBSTR( _uuid, 15, 4 ),
		SUBSTR( _uuid, 10, 4 ),
		SUBSTR( _uuid, 1, 8 ),
		SUBSTR( _uuid, 20, 4 ),
	SUBSTR( _uuid, 25 ) 
));

