create
    definer = c3_admin@`%` procedure sp_reporte_kardex(IN p_almacen char(36), IN p_producto char(36), IN p_fi date,
                                                       IN p_ff date, IN p_saldo decimal(10, 2))
BEGIN
	SET @saldo = p_saldo;
	SELECT
		k.fecha,
		k.operacion,
		k.ingresos,
		k.salidas
	FROM
		vw_kardex k 
	WHERE
		k.almacen_id = p_almacen 
		AND k.producto_id = p_producto 
		AND k.fecha BETWEEN p_fi 
		AND p_ff;
END;

