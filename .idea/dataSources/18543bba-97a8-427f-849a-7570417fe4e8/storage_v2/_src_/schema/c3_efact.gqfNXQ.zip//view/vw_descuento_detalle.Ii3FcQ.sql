create view vw_descuento_detalle as
select `m`.`movimiento_id`                                                                                    AS `movimiento_id`,
       `m`.`fecha`                                                                                            AS `fecha`,
       `m`.`almacen_id`                                                                                       AS `almacen_id`,
       `m`.`cliente_id`                                                                                       AS `cliente_id`,
       `m`.`serie`                                                                                            AS `serie`,
       `m`.`numero`                                                                                           AS `numero`,
       `md`.`producto_id`                                                                                     AS `producto_id`,
       `md`.`cantidad`                                                                                        AS `cantidad`,
       round(`md`.`precio_unitario`, 2)                                                                       AS `p_unitario`,
       round(`md`.`precio_total` / 1.18, 2)                                                                   AS `v_venta`,
       round(`md`.`precio_total` / 1.18 * 0.18, 2)                                                            AS `igv`,
       round(`md`.`precio_total`, 2)                                                                          AS `p_venta`,
       round(`md`.`precio_unitario` - `md`.`precio_unitario` * ifnull(`m`.`descuento`, 0) / 100,
             2)                                                                                               AS `dp_unitario`,
       round((`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100) / 1.18,
             2)                                                                                               AS `dv_venta`,
       round((`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100) / 1.18 * 0.18,
             2)                                                                                               AS `d_igv`,
       round(`md`.`precio_total` - `md`.`precio_total` * ifnull(`m`.`descuento`, 0) / 100,
             2)                                                                                               AS `dp_venta`,
       `m`.`descuento`                                                                                        AS `discount_percent`,
       `m`.`date_created`                                                                                     AS `date_created`,
       `m`.`estado`                                                                                           AS `estado`
from (`c3_efact`.`movimiento` `m`
         join `c3_efact`.`movimiento_detalle` `md` on (`m`.`movimiento_id` = `md`.`movimiento_id`))
where `m`.`numero` > 0
order by `m`.`date_created` desc;

