create
    definer = c3_admin@`%` procedure sp_bi_venta_por_mes(IN p_local char(36))
BEGIN
	SELECT
		td.month_name AS mes,
		sum( ifnull( v.p_venta, 0 ) ) AS venta 
	FROM
		time_dimension td
		LEFT JOIN vw_descuento v ON td.db_date = v.fecha 
		AND v.estado = 1 
		AND v.local_id = p_local
	WHERE
		YEAR ( td.db_date ) = YEAR ( convert_tz( NOW( ), 'UTC', 'America/Lima' ) ) 
	GROUP BY
		td.month_name 
	ORDER BY
		td.`month`;
END;

