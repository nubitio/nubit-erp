create view vw_movimiento as
select `m`.`movimiento_id`  AS `movimiento_id`,
       `m`.`tipo_id`        AS `tipo_id`,
       `m`.`fecha`          AS `fecha`,
       `m`.`operacion_id`   AS `operacion_id`,
       `m`.`almacen_id`     AS `almacen_id`,
       `m`.`proveedor_id`   AS `proveedor_id`,
       `m`.`cliente_id`     AS `cliente_id`,
       `m`.`tipo_pago`      AS `tipo_pago`,
       `m`.`tipo_tarjeta`   AS `tipo_tarjeta`,
       `m`.`serie`          AS `serie`,
       `m`.`numero`         AS `numero`,
       `m`.`descuento`      AS `descuento`,
       `d`.`p_venta`        AS `total`,
       `m`.`glosa`          AS `glosa`,
       `m`.`orden_id`       AS `orden_id`,
       `m`.`estado`         AS `estado`,
       `m`.`date_created`   AS `date_created`,
       `m`.`date_updated`   AS `date_updated`,
       `o`.`descripcion`    AS `operacion`,
       `l`.`local_id`       AS `local_id`,
       `l`.`descripcion`    AS `local`,
       `a`.`descripcion`    AS `almacen`,
       `c`.`razon_social`   AS `cliente`,
       `i`.`comprobante_id` AS `comprobante_id`
from ((((((`c3_efact`.`movimiento` `m` join `c3_efact`.`vw_descuento` `d` on (`d`.`movimiento_id` = `m`.`movimiento_id`)) join `c3_efact`.`almacen` `a` on (`a`.`almacen_id` = `m`.`almacen_id`)) join `c3_efact`.`local` `l` on (`l`.`local_id` = `a`.`local_id`)) join `c3_efact`.`operacion` `o` on (`o`.`operacion_id` = `m`.`operacion_id`)) left join `c3_efact`.`cliente` `c` on (`c`.`ruc` = `m`.`cliente_id`))
         left join `c3_efact`.`comprobante` `i` on (`i`.`movimiento_id` = `m`.`movimiento_id`))
order by `m`.`fecha` desc;

